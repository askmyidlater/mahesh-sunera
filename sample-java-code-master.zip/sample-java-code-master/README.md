# Sunera Technology Codethon
This repository consists of java code which is used for implementation for sample CICD pipeline including code coverage
